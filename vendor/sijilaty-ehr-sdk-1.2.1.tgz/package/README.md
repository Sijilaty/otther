# @sijilaty/ehr-sdk

TypeScript SDK for Sijil — a maintained fork of [`@sijil/sdk`](https://www.npmjs.com/package/@sijil/sdk), pinned to upstream **v4.3.14** (fork **v1.2.0**), with helpers to route **zambda**, **project**, and **FHIR** traffic through the **Sijil Go gateway** or **Tyk** instead of `*.zapehr.com`.

Reconcile with upstream **on demand only** — when a specific upstream fix or feature is
needed — not on a schedule. See [docs/DEVELOPMENT.md](./docs/DEVELOPMENT.md#syncing-from-upstream-sijilsdk).

| Resource | URL |
|----------|-----|
| GitHub | https://github.com/Sijilaty/ehr-sdk |
| npm | https://www.npmjs.com/package/@sijilaty/ehr-sdk |
| Upstream | https://www.npmjs.com/package/@sijil/sdk |

## Quick start

```bash
npm install @sijilaty/ehr-sdk
```

```ts
import { createSijilClient } from '@sijilaty/ehr-sdk';

const client = createSijilClient({
  apiBaseUrl: 'http://localhost:8080',
  accessToken: await getAccessToken(),
  projectId: 'your-project-id',
});

await client.fhir.search({ resourceType: 'Patient', params: [] });
```

## Documentation

| Doc | Contents |
|-----|----------|
| [docs/API.md](./docs/API.md) | Exports, Sijil URL mapping, env vars, Sijil usage |
| [docs/BUILD.md](./docs/BUILD.md) | esbuild + TypeScript, output layout, Homebrew vs npm |
| [docs/DEVELOPMENT.md](./docs/DEVELOPMENT.md) | Clone, local dev, link into sijil-web |
| [docs/RELEASE.md](./docs/RELEASE.md) | Branch-based CI releases, npm tokens, GitHub Actions |
| [docs/SIJIL-WEB.md](./docs/SIJIL-WEB.md) | Drop-in for `@sijil/sdk`, `createAppSijil` |
| [docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md) | Fork lineage, repo layout, CI overview |
| [AGENTS.md](./AGENTS.md) | Rules for AI coding agents |

## Credentials

```bash
./scripts/setup-credentials.sh   # npm ~/.npmrc + GitHub NPM_TOKEN
```

## Drop-in replacement

```json
"@sijil/sdk": "npm:@sijilaty/ehr-sdk@^1.0.0"
```

## License

MIT — upstream Sijil SDK © Sijil; Sijil changes © [Sijilaty](https://github.com/Sijilaty).
